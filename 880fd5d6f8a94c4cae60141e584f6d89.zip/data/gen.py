根据你提供的数据方案，我已经为你编写了一套完整的 Python 数据生成器。

该脚本严格遵循了 **CSP-S T4** 的难度要求，并针对 20 个测试点各自的特征（手算点、基础DP、条状特化、超大遮罩、阶梯合围、角落临界点等）进行了针对性的生成逻辑设计。

```python
import os
import random
import math

# 标记为 GEN_PY

def write_input_file(filename, N, M, K, obstacles):
    """
    统一的输入文件写入格式。
    第一行: N M K
    接下来 K 行: X_i Y_i R_i
    """
    with open(filename, 'w') as f:
        f.write(f"{N} {M} {K}\n")
        for x, y, r in obstacles:
            f.write(f"{x} {y} {r}\n")

def make_directory(path="data"):
    if not os.path.exists(path):
        os.makedirs(path)

def generate_all_data():
    base_dir = "data"
    make_directory(base_dir)
    
    print("开始生成测试数据...")

    # =========================================================================
    # 测试点 1 ~ 2：小规模手算/无脑爆搜点
    # =========================================================================
    for t in [1, 2]:
        N = random.randint(5, 10)
        M = random.randint(5, 10)
        if t == 1:
            K = 0
            obstacles = []
        else:
            K = random.randint(2, 5)
            obstacles = []
            for _ in range(K):
                x = random.randint(0, N)
                y = random.randint(0, M)
                r = random.randint(1, 3)
                obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 3 ~ 4：基础 DP 点 (N, M <= 100, K <= 50)
    # =========================================================================
    for t in [3, 4]:
        N = random.randint(80, 100)
        M = random.randint(80, 100)
        K = random.randint(30, 50)
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 20)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 5 ~ 6：中等规模点 (N, M <= 2000, K <= 2000)
    # =========================================================================
    for t in [5, 6]:
        N = random.randint(1800, 2000)
        M = random.randint(1800, 2000)
        K = random.randint(1500, 2000)
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 10)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 7：条状特化点（极度扁平 N=1e5, M=1, K<=1000）
    # =========================================================================
    {
        N = 100000
        M = 1
        K = random.randint(800, 1000)
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 100)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/7.in", N, M, K, obstacles)
    }

    # =========================================================================
    # 测试点 8：条状特化点（极度狭长 N=1, M=1e5, K<=1000）
    # =========================================================================
    {
        N = 1
        M = 100000
        K = random.randint(800, 1000)
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 100)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/8.in", N, M, K, obstacles)
    }

    # =========================================================================
    # 测试点 9：空旷无障碍点 (N, M <= 1e5, K = 0)
    # =========================================================================
    {
        N = 100000
        M = 100000
        K = 0
        obstacles = []
        write_input_file(f"{base_dir}/9.in", N, M, K, obstacles)
    }

    # =========================================================================
    # 测试点 10：单点障碍点 (N, M <= 1e5, K <= 1e5, R_i = 0)
    # =========================================================================
    {
        N = 100000
        M = 100000
        K = 100000
        obstacles = []
        # 随机洒点，半径全为 0
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            obstacles.append((x, y, 0))
        write_input_file(f"{base_dir}/10.in", N, M, K, obstacles)
    }

    # =========================================================================
    # 测试点 11：超大遮罩点 (K = 1, R_i 极大，封死起点或必经之路，答案为 0)
    # =========================================================================
    {
        N = 100000
        M = 100000
        K = 1
        # 放置在中间，但半径极大，足以覆盖全图或切断路径
        obstacles = [(50000, 50000, 200000)]
        write_input_file(f"{base_dir}/11.in", N, M, K, obstacles)
    }

    # =========================================================================
    # 测试点 12 ~ 13：多重重叠点 (大量干扰源在一特定核心区域内堆叠)
    # =========================================================================
    for t in [12, 13]:
        N = 50000
        M = 50000
        K = 50000
        obstacles = []
        # 让障碍物集中在某些中心区，形成高频的重叠和解除覆盖
        center_x, center_y = N // 2, M // 2
        for _ in range(K):
            # 使用高斯分布或集中在核心区域附近
            x = int(random.gauss(center_x, N // 10))
            y = int(random.gauss(center_y, M // 10))
            x = max(0, min(N, x))
            y = max(0, min(M, y))
            r = random.randint(1, 500)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 14 ~ 15：阶梯式合围点 (对角线方向分布，形成“防火墙”)
    # =========================================================================
    for t in [14, 15]:
        N = 100000
        M = 100000
        K = 100000
        obstacles = []
        
        # 构造一条从 (0, M) 到 (N, 0) 的对角线防火墙，或者若干道阶梯
        # 预留一部分给“防火墙”，其余随机
        wall_count = 60000
        rand_count = K - wall_count
        
        for i in range(wall_count):
            # 沿对角线分布：x 从 0 到 N 渐变，y 从 M 到 0 渐变
            progress = i / wall_count
            x = int(progress * N)
            y = int((1 - progress) * M)
            # 添加一些抖动
            x = max(0, min(N, x + random.randint(-5, 5)))
            y = max(0, min(M, y + random.randint(-5, 5)))
            r = random.randint(1500, 2000)
            obstacles.append((x, y, r))
            
        for _ in range(rand_count):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 2000)
            obstacles.append((x, y, r))
            
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 16 ~ 17：全随机综合点
    # =========================================================================
    for t in [16, 17]:
        N = 100000
        M = 100000
        K = 100000
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 100000)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 18 ~ 19：大数据高密度点 (N, M, K 满上限，R_i 很大，频繁触发满区间修改)
    # =========================================================================
    for t in [18, 19]:
        N = 100000
        M = 100000
        K = 100000
        obstacles = []
        for _ in range(K):
            x = random.randint(0, N)
            y = random.randint(0, M)
            # 大半径，导致转为矩形后极易覆盖扫描线的大段甚至全段
            r = random.randint(100000, 200000)
            obstacles.append((x, y, r))
        write_input_file(f"{base_dir}/{t}.in", N, M, K, obstacles)

    # =========================================================================
    # 测试点 20：终极卡常/边界点 (紧贴四个角落，精确测试 <= R_i 的临界情况)
    # =========================================================================
    {
        N = 100000
        M = 100000
        K = 100000
        obstacles = []
        
        # 1. 紧贴 A(0,0)，不覆盖 (0,0) -> 半径为 r, 放到 (0, r+1) 或 (r+1, 0)
        # 或者是障碍物距离 A 恰好为 r+1
        obstacles.append((0, 10, 9))
        obstacles.append((10, 0, 9))
        
        # 2. 紧贴 B(N,M)，不覆盖 (N,M) -> 距离为 r+1
        obstacles.append((N, M - 15, 14))
        obstacles.append((N - 15, M, 14))
        
        # 3. 紧贴 (0,M) 与 (N,0)
        obstacles.append((0, M - 20, 19))
        obstacles.append((N - 20, 0, 19))
        
        # 剩余的 K - 6 个点在大范围内高密度分布，且包含各种大半径和奇偶交替位置
        for _ in range(K - 6):
            x = random.randint(0, N)
            y = random.randint(0, M)
            r = random.randint(1, 200000)
            obstacles.append((x, y, r))
            
        write_input_file(f"{base_dir}/20.in", N, M, K, obstacles)
    }

    print("所有测试点（1~20）输入数据 (.in) 生成完毕！")

if __name__ == "__main__":
    generate_all_data()
```

### 设计说明及如何对齐大纲细节

1. **结构对齐**：脚本使用一个统一的 `write_input_file` 函数来规范输入文件格式。20 个测试点完全按照表格中划分的梯度（1~2、3~4、…… 直到 20）进行函数段落设计。
2. **负数与边界（测试点 7, 8, 18）**：
   - 测试点 7 和 8 刻意产生了 $1 \times 10^5$ 和 $10^5 \times 1$ 的极其极端的“条状网格”。这会让坐标变换后的 $v = x - y$ 极度偏向正数或负数一侧（最大达到 $10^5$ 或 $-10^5$），完美卡掉选手没有加合适 `base` 偏移量的线段树数组。
3. **阶梯合围（测试点 14 ~ 15）**：
   - 算法通过在反对角线 $(0, M)$ 到 $(N, 0)$ 的线性轨迹上辅以 $\pm 5$ 随机扰动密集布设障碍，半径设为 $1500 \sim 2000$。这种几何构造会在旋转后的坐标系中形成一条近乎连续的“禁行带”，迫使线段树大面积清零并测试连通性状态。
4. **临界精度的精确考查（测试点 20）**：
   - 针对曼哈顿距离 $\le R_i$ 的临界点，在四个核心死角放置了诸如 `(0, 10, 9)` 的点。到 $(0,0)$ 的曼哈顿距离为 $10$，大于半径 $9$，刚好不被覆盖。以此强行检验选手代码中写的是 `<` 还是 `<=`。