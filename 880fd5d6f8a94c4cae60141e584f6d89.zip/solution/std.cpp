#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int MOD = 1e9 + 7;

// 线段树节点：用于动态维护当前行状态下的 DP 值与区间清零操作
struct Node {
    int l, r;
    long long sum;
    long long lazy; // 懒标记：-1 表示无标记，0 表示需要清零
} tree[800005];

void build(int node, int l, int r) {
    tree[node].l = l;
    tree[node].r = r;
    tree[node].sum = 0;
    tree[node].lazy = -1;
    if (l == r) return;
    int mid = (l + r) >> 1;
    build(node << 1, l, mid);
    build(node << 1 | 1, mid + 1, r);
}

void pushdown(int node) {
    if (tree[node].lazy == 0) {
        tree[node << 1].sum = 0;
        tree[node << 1].lazy = 0;
        tree[node << 1 | 1].sum = 0;
        tree[node << 1 | 1].lazy = 0;
        tree[node].lazy = -1;
    }
}

void pushup(int node) {
    tree[node].sum = (tree[node << 1].sum + tree[node << 1 | 1].sum) % MOD;
}

// 区间清零
void update_zero(int node, int ql, int qr) {
    if (ql > qr) return;
    if (tree[node].l >= ql && tree[node].r <= qr) {
        tree[node].sum = 0;
        tree[node].lazy = 0;
        return;
    }
    pushdown(node);
    int mid = (tree[node].l + tree[node].r) >> 1;
    if (ql <= mid) update_zero(node << 1, ql, qr);
    if (qr > mid) update_zero(node << 1 | 1, ql, qr);
    pushup(node);
}

// 单点修改（添加方案数）
void update_add(int node, int idx, long long val) {
    if (tree[node].l == tree[node].r) {
        tree[node].sum = (tree[node].sum + val) % MOD;
        return;
    }
    pushdown(node);
    int mid = (tree[node].l + tree[node].r) >> 1;
    if (idx <= mid) update_add(node << 1, idx, val);
    else update_add(node << 1 | 1, idx, val);
    pushup(node);
}

// 区间求和查询
long long query(int node, int ql, int qr) {
    if (ql > qr) return 0;
    if (tree[node].l >= ql && tree[node].r <= qr) {
        return tree[node].sum;
    }
    pushdown(node);
    int mid = (tree[node].l + tree[node].r) >> 1;
    long long res = 0;
    if (ql <= mid) res = (res + query(node << 1, ql, qr)) % MOD;
    if (qr > mid) res = (res + query(node << 1 | 1, ql, qr)) % MOD;
    return res;
}

// 存储干扰源在某一行产生的禁用区间
struct ObstacleRange {
    int yl, yr;
};

void solve() {
    int n, m, k;
    if (!(cin >> n >> m >> k)) return;

    // 用邻接表按行组织障碍物，避免大矩阵的开销
    vector<vector<ObstacleRange>> row_obstacles(n + 1);

    for (int i = 0; i < k; i++) {
        int xi, yi, ri;
        cin >> xi >> yi >> ri;

        // 计算该干扰源对每一行产生的影响范围
        int start_x = max(0, xi - ri);
        int end_x = min(n, xi + ri);
        for (int x = start_x; x <= end_x; x++) {
            int rem = ri - abs(x - xi);
            int yl = max(0, yi - rem);
            int yr = min(m, yi + rem);
            if (yl <= yr) {
                row_obstacles[x].push_back({yl, yr});
            }
        }
    }

    // 初始化线段树维护 y 轴 [0, m]
    build(1, 0, m);

    // 起点初始化
    update_add(1, 0, 1);
    
    // 如果起点本身就有障碍，直接清零
    for (const auto& obs : row_obstacles[0]) {
        update_zero(1, obs.yl, obs.yr);
    }

    // 逐行进行 DP 滚动转移
    for (int x = 0; x <= n; x++) {
        if (x > 0) {
            // 从 x-1 行向下转移到 x 行
            // 此时线段树内存储的已经是上一行的值 f(x-1, y)
            // 根据 f(x, y) = f(x-1, y) + f(x, y-1) 递推
            // 我们可以自左向右通过前缀和思想进行线段树的单点更新
            for (int y = 0; y <= m; y++) {
                long long from_top = query(1, y, y);
                long long from_left = (y > 0) ? query(1, y - 1, y - 1) : 0;
                // 先清空原位置，再写入新值
                update_zero(1, y, y);
                update_add(1, y, (from_top + from_left) % MOD);
            }
        } else {
            // 第 0 行单独向右递推
            for (int y = 1; y <= m; y++) {
                long long from_left = query(1, y - 1, y - 1);
                update_add(1, y, from_left);
            }
        }

        // 应用当前行的所有障碍物，将对应的禁用 y 区间清零
        for (const auto& obs : row_obstacles[x]) {
            update_zero(1, obs.yl, obs.yr);
        }
    }

    // 最终答案即为终点 (n, m) 位置上的方案数
    cout << query(1, m, m) << "\n";
}

int main() {
    // 优化标准输入输出流的性能
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}